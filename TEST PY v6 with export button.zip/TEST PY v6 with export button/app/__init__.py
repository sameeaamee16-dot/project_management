import click
from flask import Flask
from sqlalchemy import inspect, text

from app.config import Config
from app.extensions import db, login_manager
from app.models import Department, User
from app.routes import register_blueprints


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    db.init_app(app)
    login_manager.init_app(app)
    register_blueprints(app)
    register_cli_commands(app)

    with app.app_context():
        db.create_all()
        ensure_schema_updates()

    return app


def ensure_schema_updates():
    inspector = inspect(db.engine)

    if not inspector.has_table("departments"):
        Department.__table__.create(bind=db.engine)
        inspector = inspect(db.engine)

    project_columns = {column["name"] for column in inspector.get_columns("projects")}
    if "department_id" not in project_columns:
        db.session.execute(
            text("ALTER TABLE projects ADD COLUMN department_id INTEGER NULL")
        )
        db.session.commit()

        dialect = db.engine.dialect.name
        if dialect == "mysql":
            db.session.execute(
                text(
                    "ALTER TABLE projects "
                    "ADD CONSTRAINT fk_projects_department "
                    "FOREIGN KEY (department_id) REFERENCES departments(id) "
                    "ON DELETE SET NULL"
                )
            )
        elif dialect == "sqlite":
            pass
        db.session.commit()

    task_columns = {column["name"] for column in inspector.get_columns("tasks")}
    if "department_id" not in task_columns:
        db.session.execute(text("ALTER TABLE tasks ADD COLUMN department_id INTEGER NULL"))
        db.session.commit()

        dialect = db.engine.dialect.name
        if dialect == "mysql":
            db.session.execute(
                text(
                    "ALTER TABLE tasks "
                    "ADD CONSTRAINT fk_tasks_department "
                    "FOREIGN KEY (department_id) REFERENCES departments(id) "
                    "ON DELETE SET NULL"
                )
            )
        elif dialect == "sqlite":
            pass
        db.session.commit()

    task_defaults = [
        ("tasks", "status", "ToDo", "Not Started"),
        ("subtasks", "status", "ToDo", "Not Started"),
    ]
    for table_name, column_name, new_value, old_value in task_defaults:
        db.session.execute(
            text(
                f"UPDATE {table_name} SET {column_name} = :new_value "
                f"WHERE {column_name} = :old_value"
            ),
            {"new_value": new_value, "old_value": old_value},
        )
    db.session.commit()


@login_manager.user_loader
def load_user(user_id: str):
    return User.query.get(int(user_id))


def register_cli_commands(app: Flask):
    @app.cli.command("create-admin")
    @click.option("--username", prompt=True)
    @click.option("--password", prompt=True, hide_input=True, confirmation_prompt=True)
    def create_admin(username: str, password: str):
        existing = User.query.filter_by(username=username).first()
        if existing:
            click.echo("User already exists.")
            return

        admin = User(username=username, role="admin")
        admin.set_password(password)
        db.session.add(admin)
        db.session.commit()
        click.echo("Admin user created successfully.")
