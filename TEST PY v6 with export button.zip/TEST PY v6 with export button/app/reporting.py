from __future__ import annotations

from collections import defaultdict
from datetime import date, datetime
from io import BytesIO

from flask import current_app

try:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import (
        KeepTogether,
        PageBreak,
        Paragraph,
        SimpleDocTemplate,
        Spacer,
        Table,
        TableStyle,
    )
    REPORTLAB_IMPORT_ERROR = None
except ImportError as exc:
    REPORTLAB_IMPORT_ERROR = exc
    colors = None
    A4 = None
    ParagraphStyle = None
    getSampleStyleSheet = None
    mm = None
    KeepTogether = None
    PageBreak = None
    Paragraph = None
    SimpleDocTemplate = None
    Spacer = None
    Table = None
    TableStyle = None


STATUS_COLORS = {
    "ToDo": "#64748B",
    "In Progress": "#2563EB",
    "Review": "#D97706",
    "Completed": "#16A34A",
}

SEVERITY_COLORS = {
    "Low": "#78716C",
    "Medium": "#C2410C",
    "High": "#DC2626",
    "Critical": "#7F1D1D",
}


def parse_filter_date(value: str | None):
    if not value:
        return None
    return datetime.strptime(value, "%Y-%m-%d").date()


def format_date(value: date | None):
    return value.strftime("%d %b %Y") if value else "No deadline"


def normalize_filters(raw_filters: dict, *, include_assignee: bool = False):
    filters = {
        "project_id": raw_filters.get("project_id", "", type=int)
        if hasattr(raw_filters, "get")
        else raw_filters.get("project_id"),
        "status": (raw_filters.get("status", "") if hasattr(raw_filters, "get") else raw_filters.get("status", "")).strip(),
        "severity": (raw_filters.get("severity", "") if hasattr(raw_filters, "get") else raw_filters.get("severity", "")).strip(),
        "date_from": (raw_filters.get("date_from", "") if hasattr(raw_filters, "get") else raw_filters.get("date_from", "")).strip(),
        "date_to": (raw_filters.get("date_to", "") if hasattr(raw_filters, "get") else raw_filters.get("date_to", "")).strip(),
    }
    if include_assignee:
        filters["assigned_to"] = (
            raw_filters.get("assigned_to", "", type=int)
            if hasattr(raw_filters, "get")
            else raw_filters.get("assigned_to")
        )
    return filters


def apply_task_export_filters(query, filters, task_model):
    date_from = parse_filter_date(filters.get("date_from"))
    date_to = parse_filter_date(filters.get("date_to"))

    if filters.get("project_id"):
        query = query.filter(task_model.project_id == filters["project_id"])
    if filters.get("status"):
        query = query.filter(task_model.status == filters["status"])
    if filters.get("severity"):
        query = query.filter(task_model.severity == filters["severity"])
    if filters.get("assigned_to"):
        query = query.filter(task_model.assigned_to == filters["assigned_to"])
    if date_from:
        query = query.filter(task_model.due_date.is_not(None), task_model.due_date >= date_from)
    if date_to:
        query = query.filter(task_model.due_date.is_not(None), task_model.due_date <= date_to)

    return query


def build_export_snapshot(tasks):
    today = date.today()
    project_rows_map = defaultdict(
        lambda: {
            "project_name": "",
            "department_name": "No department",
            "owner_names": set(),
            "task_count": 0,
            "completed_count": 0,
            "overdue_count": 0,
            "completion_pct": 0,
        }
    )

    summary = {
        "project_count": 0,
        "task_count": len(tasks),
        "completed_count": sum(task.status == "Completed" for task in tasks),
        "open_count": sum(task.status != "Completed" for task in tasks),
        "overdue_count": sum(
            task.status != "Completed" and task.due_date is not None and task.due_date < today
            for task in tasks
        ),
    }

    for task in tasks:
        row = project_rows_map[task.project_id]
        row["project_name"] = task.project.name
        row["department_name"] = (
            task.project.department.name if task.project.department else "No department"
        )
        row["task_count"] += 1
        row["completed_count"] += int(task.status == "Completed")
        row["overdue_count"] += int(
            task.status != "Completed" and task.due_date is not None and task.due_date < today
        )
        if task.assignee:
            row["owner_names"].add(task.assignee.username)

    project_rows = []
    for row in project_rows_map.values():
        row["owner_names"] = ", ".join(sorted(row["owner_names"])) or "Unassigned"
        row["completion_pct"] = (
            int(round((row["completed_count"] / row["task_count"]) * 100))
            if row["task_count"]
            else 0
        )
        project_rows.append(row)

    project_rows.sort(key=lambda item: item["project_name"].lower())
    summary["project_count"] = len(project_rows)

    return summary, project_rows


def build_filter_badges(filters, project_lookup, user_lookup=None):
    badges = []
    if filters.get("project_id"):
        badges.append(("Project", project_lookup.get(filters["project_id"], "Selected project")))
    if filters.get("status"):
        badges.append(("Status", filters["status"]))
    if filters.get("severity"):
        badges.append(("Severity", filters["severity"]))
    if filters.get("assigned_to") and user_lookup is not None:
        badges.append(("Assignee", user_lookup.get(filters["assigned_to"], "Selected member")))
    if filters.get("date_from"):
        badges.append(("From", filters["date_from"]))
    if filters.get("date_to"):
        badges.append(("To", filters["date_to"]))
    return badges or [("Scope", "All matching records")]


def _build_styles():
    if REPORTLAB_IMPORT_ERROR is not None:
        raise RuntimeError("reportlab is required for PDF exports") from REPORTLAB_IMPORT_ERROR
    styles = getSampleStyleSheet()
    styles.add(
        ParagraphStyle(
            name="ReportTitle",
            parent=styles["Heading1"],
            fontName="Helvetica-Bold",
            fontSize=24,
            leading=28,
            textColor=colors.HexColor("#0F172A"),
            spaceAfter=6,
        )
    )
    styles.add(
        ParagraphStyle(
            name="ReportSubtitle",
            parent=styles["BodyText"],
            fontName="Helvetica",
            fontSize=10,
            leading=14,
            textColor=colors.HexColor("#475569"),
        )
    )
    styles.add(
        ParagraphStyle(
            name="SectionLabel",
            parent=styles["Heading2"],
            fontName="Helvetica-Bold",
            fontSize=11,
            leading=14,
            textColor=colors.HexColor("#1D4ED8"),
            spaceAfter=8,
        )
    )
    styles.add(
        ParagraphStyle(
            name="CardValue",
            parent=styles["Heading2"],
            fontName="Helvetica-Bold",
            fontSize=18,
            leading=20,
            textColor=colors.white,
            alignment=1,
        )
    )
    styles.add(
        ParagraphStyle(
            name="CardLabel",
            parent=styles["BodyText"],
            fontName="Helvetica",
            fontSize=8,
            leading=10,
            textColor=colors.white,
            alignment=1,
        )
    )
    styles.add(
        ParagraphStyle(
            name="SmallMuted",
            parent=styles["BodyText"],
            fontName="Helvetica",
            fontSize=8,
            leading=10,
            textColor=colors.HexColor("#64748B"),
        )
    )
    styles.add(
        ParagraphStyle(
            name="TaskText",
            parent=styles["BodyText"],
            fontName="Helvetica",
            fontSize=8.5,
            leading=11,
            textColor=colors.HexColor("#0F172A"),
        )
    )
    return styles


def _metric_cards(summary, styles):
    if REPORTLAB_IMPORT_ERROR is not None:
        raise RuntimeError("reportlab is required for PDF exports") from REPORTLAB_IMPORT_ERROR
    card_items = [
        ("Projects", summary["project_count"], colors.HexColor("#2563EB")),
        ("Tasks", summary["task_count"], colors.HexColor("#0F766E")),
        ("Completed", summary["completed_count"], colors.HexColor("#16A34A")),
        ("Overdue", summary["overdue_count"], colors.HexColor("#DC2626")),
    ]
    cells = []
    for label, value, background in card_items:
        content = [
            Paragraph(str(value), styles["CardValue"]),
            Spacer(1, 2),
            Paragraph(label.upper(), styles["CardLabel"]),
        ]
        table = Table([[item] for item in content], colWidths=[38 * mm])
        table.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, -1), background),
                    ("BOX", (0, 0), (-1, -1), 0, background),
                    ("LEFTPADDING", (0, 0), (-1, -1), 10),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 10),
                    ("TOPPADDING", (0, 0), (-1, -1), 10),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
                    ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                ]
            )
        )
        cells.append(table)

    row = Table([cells], colWidths=[42 * mm, 42 * mm, 42 * mm, 42 * mm], hAlign="LEFT")
    row.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP")]))
    return row


def _badge_table(filter_badges, styles):
    if REPORTLAB_IMPORT_ERROR is not None:
        raise RuntimeError("reportlab is required for PDF exports") from REPORTLAB_IMPORT_ERROR
    data = []
    for label, value in filter_badges:
        data.append(
            [
                Paragraph(f"<b>{label}</b>", styles["TaskText"]),
                Paragraph(value, styles["TaskText"]),
            ]
        )
    table = Table(data, colWidths=[34 * mm, 136 * mm], hAlign="LEFT")
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#EFF6FF")),
                ("ROWBACKGROUNDS", (0, 0), (-1, -1), [colors.HexColor("#EFF6FF"), colors.HexColor("#F8FAFC")]),
                ("BOX", (0, 0), (-1, -1), 0.6, colors.HexColor("#BFDBFE")),
                ("INNERGRID", (0, 0), (-1, -1), 0.6, colors.HexColor("#DBEAFE")),
                ("LEFTPADDING", (0, 0), (-1, -1), 10),
                ("RIGHTPADDING", (0, 0), (-1, -1), 10),
                ("TOPPADDING", (0, 0), (-1, -1), 7),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
            ]
        )
    )
    return table


def _project_summary_table(project_rows, styles):
    if REPORTLAB_IMPORT_ERROR is not None:
        raise RuntimeError("reportlab is required for PDF exports") from REPORTLAB_IMPORT_ERROR
    data = [
        [
            Paragraph("<b>Project</b>", styles["TaskText"]),
            Paragraph("<b>Department</b>", styles["TaskText"]),
            Paragraph("<b>Owners</b>", styles["TaskText"]),
            Paragraph("<b>Tasks</b>", styles["TaskText"]),
            Paragraph("<b>Done</b>", styles["TaskText"]),
            Paragraph("<b>Progress</b>", styles["TaskText"]),
        ]
    ]
    for row in project_rows:
        data.append(
            [
                Paragraph(row["project_name"], styles["TaskText"]),
                Paragraph(row["department_name"], styles["TaskText"]),
                Paragraph(row["owner_names"], styles["TaskText"]),
                Paragraph(str(row["task_count"]), styles["TaskText"]),
                Paragraph(str(row["completed_count"]), styles["TaskText"]),
                Paragraph(f'{row["completion_pct"]}%', styles["TaskText"]),
            ]
        )

    table = Table(
        data,
        colWidths=[40 * mm, 32 * mm, 42 * mm, 18 * mm, 18 * mm, 22 * mm],
        repeatRows=1,
        hAlign="LEFT",
    )
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0F172A")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F8FAFC")]),
                ("BOX", (0, 0), (-1, -1), 0.6, colors.HexColor("#CBD5E1")),
                ("INNERGRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#E2E8F0")),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                ("TOPPADDING", (0, 0), (-1, -1), 7),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ]
        )
    )
    return table


def _task_detail_block(task, styles):
    if REPORTLAB_IMPORT_ERROR is not None:
        raise RuntimeError("reportlab is required for PDF exports") from REPORTLAB_IMPORT_ERROR
    status_color = STATUS_COLORS.get(task.status, "#334155")
    severity_color = SEVERITY_COLORS.get(task.severity, "#7C3AED")

    header = Table(
        [
            [
                Paragraph(f"<b>{task.title}</b>", styles["TaskText"]),
                Paragraph(
                    f'<font color="{status_color}"><b>{task.status}</b></font>',
                    styles["TaskText"],
                ),
                Paragraph(
                    f'<font color="{severity_color}"><b>{task.severity}</b></font>',
                    styles["TaskText"],
                ),
            ]
        ],
        colWidths=[90 * mm, 34 * mm, 28 * mm],
    )
    header.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#E0F2FE")),
                ("BOX", (0, 0), (-1, -1), 0.6, colors.HexColor("#BAE6FD")),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                ("TOPPADDING", (0, 0), (-1, -1), 7),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
            ]
        )
    )

    meta_lines = [
        f"<b>Project:</b> {task.project.name}",
        f"<b>Assignee:</b> {task.assignee.username if task.assignee else 'Unassigned'}",
        f"<b>Department:</b> {task.department.name if task.department else 'No department'}",
        f"<b>Start:</b> {format_date(task.start_date)}",
        f"<b>Due:</b> {format_date(task.due_date)}",
        f"<b>Subtasks:</b> {sum(subtask.status == 'Completed' for subtask in task.subtasks)}/{len(task.subtasks)} completed",
    ]
    description = task.description or "No description provided."
    subtasks = (
        ", ".join(f"{subtask.title} ({subtask.status})" for subtask in task.subtasks[:5])
        if task.subtasks
        else "No subtasks"
    )

    body = Table(
        [
            [Paragraph("<br/>".join(meta_lines), styles["TaskText"])],
            [Paragraph(f"<b>Description:</b> {description}", styles["TaskText"])],
            [Paragraph(f"<b>Subtasks:</b> {subtasks}", styles["TaskText"])],
        ],
        colWidths=[152 * mm],
    )
    body.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.white),
                ("BOX", (0, 0), (-1, -1), 0.6, colors.HexColor("#DBEAFE")),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                ("TOPPADDING", (0, 0), (-1, -1), 7),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
            ]
        )
    )

    return KeepTogether([header, body, Spacer(1, 6)])


def render_task_export_pdf(
    *,
    report_title: str,
    report_subtitle: str,
    summary: dict,
    filter_badges: list[tuple[str, str]],
    project_rows: list[dict],
    tasks: list,
    generated_by: str,
):
    if REPORTLAB_IMPORT_ERROR is not None:
        raise RuntimeError("reportlab is required for PDF exports") from REPORTLAB_IMPORT_ERROR
    styles = _build_styles()
    buffer = BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        leftMargin=14 * mm,
        rightMargin=14 * mm,
        topMargin=16 * mm,
        bottomMargin=14 * mm,
        title=report_title,
        author=current_app.name,
    )

    story = [
        Paragraph(report_title, styles["ReportTitle"]),
        Paragraph(report_subtitle, styles["ReportSubtitle"]),
        Spacer(1, 4),
        Paragraph(
            f"Generated by {generated_by} on {datetime.now().strftime('%d %b %Y %I:%M %p')}",
            styles["SmallMuted"],
        ),
        Spacer(1, 12),
        _metric_cards(summary, styles),
        Spacer(1, 16),
        Paragraph("Applied Filters", styles["SectionLabel"]),
        _badge_table(filter_badges, styles),
        Spacer(1, 16),
    ]

    if project_rows:
        story.extend(
            [
                Paragraph("Project Summary", styles["SectionLabel"]),
                _project_summary_table(project_rows, styles),
                Spacer(1, 16),
            ]
        )

    story.append(Paragraph("Task Details", styles["SectionLabel"]))
    if tasks:
        for index, task in enumerate(tasks):
            if index and index % 6 == 0:
                story.append(PageBreak())
            story.append(_task_detail_block(task, styles))
    else:
        story.append(Paragraph("No tasks matched the selected filters.", styles["TaskText"]))

    def draw_page(canvas, document):
        canvas.saveState()
        canvas.setFillColor(colors.HexColor("#E0F2FE"))
        canvas.rect(0, A4[1] - (18 * mm), A4[0], 18 * mm, stroke=0, fill=1)
        canvas.setFillColor(colors.HexColor("#0F172A"))
        canvas.setFont("Helvetica-Bold", 10)
        canvas.drawString(16 * mm, A4[1] - 11 * mm, "Project Hub Export")
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(colors.HexColor("#64748B"))
        canvas.drawRightString(A4[0] - 14 * mm, 10 * mm, f"Page {document.page}")
        canvas.restoreState()

    doc.build(story, onFirstPage=draw_page, onLaterPages=draw_page)
    buffer.seek(0)
    return buffer
