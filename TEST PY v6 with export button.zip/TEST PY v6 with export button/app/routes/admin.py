from datetime import date, datetime, timedelta
from urllib.parse import urlparse

from flask import Blueprint, flash, redirect, render_template, request, send_file, url_for
from flask_login import current_user, login_required
from sqlalchemy import or_

from app.extensions import db
from app.models import Department, Notification, Project, Subtask, Task, User
from app.reporting import (
    apply_task_export_filters,
    build_export_snapshot,
    build_filter_badges,
    normalize_filters,
    parse_filter_date,
    render_task_export_pdf,
)
from app.utils import (
    NotificationService,
    TASK_SEVERITIES,
    TASK_STATUSES,
    role_required,
)

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")


def parse_date(value: str):
    if not value:
        return None
    return datetime.strptime(value, "%Y-%m-%d").date()


def redirect_target(default_endpoint: str, **values):
    target = request.form.get("next_url") or request.args.get("next_url")
    if target:
        parsed = urlparse(target)
        if not parsed.netloc and target.startswith("/"):
            return redirect(target)
    return redirect(url_for(default_endpoint, **values))


def get_notifications(limit: int = 8):
    return (
        Notification.query.filter_by(user_id=current_user.id, is_read=False)
        .order_by(Notification.created_at.desc())
        .limit(limit)
        .all()
    )


def build_project_summary(project: Project):
    total_tasks = len(project.tasks)
    completed_tasks = sum(task.status == "Completed" for task in project.tasks)
    total_subtasks = sum(len(task.subtasks) for task in project.tasks)
    completed_subtasks = sum(
        sum(subtask.status == "Completed" for subtask in task.subtasks) for task in project.tasks
    )
    completion_pct = int(round((completed_tasks / total_tasks) * 100)) if total_tasks else 0
    return {
        "project": project,
        "total_tasks": total_tasks,
        "completed_tasks": completed_tasks,
        "total_subtasks": total_subtasks,
        "completed_subtasks": completed_subtasks,
        "completion_pct": completion_pct,
    }


def build_task_summary(task: Task):
    total_subtasks = len(task.subtasks)
    completed_subtasks = sum(item.status == "Completed" for item in task.subtasks)
    subtask_pct = (
        int(round((completed_subtasks / total_subtasks) * 100)) if total_subtasks else 0
    )
    return {
        "task": task,
        "total_subtasks": total_subtasks,
        "completed_subtasks": completed_subtasks,
        "subtask_pct": subtask_pct,
    }


def build_analytics(tasks):
    today = date.today()
    tomorrow = today + timedelta(days=1)

    stats = {
        "total_projects": Project.query.count(),
        "total_tasks": len(tasks),
        "completed_tasks": sum(task.status == "Completed" for task in tasks),
        "pending_tasks": sum(task.status != "Completed" for task in tasks),
        "overdue_tasks": sum(
            task.status != "Completed" and task.due_date is not None and task.due_date < today
            for task in tasks
        ),
        "no_deadline_tasks": sum(task.due_date is None for task in tasks),
        "due_tomorrow_tasks": sum(
            task.status != "Completed" and task.due_date == tomorrow for task in tasks
        ),
    }

    status_counts = {status: 0 for status in TASK_STATUSES}
    priority_counts = {severity: 0 for severity in TASK_SEVERITIES}
    for task in tasks:
        status_counts[task.status] = status_counts.get(task.status, 0) + 1
        priority_counts[task.severity] = priority_counts.get(task.severity, 0) + 1

    total_status = sum(status_counts.values()) or 1
    status_segments = []
    offset = 0
    status_colors = {
        "ToDo": "#94a3b8",
        "In Progress": "#3b82f6",
        "Review": "#facc15",
        "Completed": "#22c55e",
    }
    for label, value in status_counts.items():
        percentage = round((value / total_status) * 100, 2)
        status_segments.append(
            {
                "label": label,
                "value": value,
                "percentage": percentage,
                "start": round(offset, 2),
                "end": round(offset + percentage, 2),
                "color": status_colors[label],
            }
        )
        offset += percentage

    max_priority = max(priority_counts.values(), default=0) or 1
    priority_colors = {
        "Low": "#d6d3d1",
        "Medium": "#f59e0b",
        "High": "#ef4444",
        "Critical": "#991b1b",
    }
    priority_bars = [
        {
            "label": label,
            "value": value,
            "height_pct": round((value / max_priority) * 100, 2),
            "color": priority_colors[label],
        }
        for label, value in priority_counts.items()
    ]

    return stats, status_segments, priority_bars


def validate_project_dates(start_date, end_date):
    if not start_date or not end_date:
        flash("Project start and end dates are required.", "danger")
        return False
    if end_date < start_date:
        flash("Project end date cannot be before start date.", "danger")
        return False
    return True


def validate_task_payload(task: Task | None = None):
    title = request.form.get("title", "").strip()
    if not title:
        flash("Task title is required.", "danger")
        return None

    status = request.form.get("status", task.status if task else "ToDo")
    severity = request.form.get("severity", task.severity if task else "Low")
    if status not in TASK_STATUSES:
        flash("Invalid task status selected.", "danger")
        return None
    if severity not in TASK_SEVERITIES:
        flash("Invalid task severity selected.", "danger")
        return None

    start_date = parse_date(request.form.get("start_date")) or (task.start_date if task else None)
    due_date = parse_date(request.form.get("due_date"))
    if request.form.get("due_date") == "" and task:
        due_date = None
    elif due_date is None and task:
        due_date = task.due_date

    if not start_date:
        flash("Task start date is required.", "danger")
        return None
    if due_date and due_date < start_date:
        flash("Due date cannot be before start date.", "danger")
        return None

    project_id = request.form.get("project_id", type=int) or (task.project_id if task else None)
    project = Project.query.get_or_404(project_id)
    department_id = request.form.get("department_id", type=int)
    if request.form.get("department_id") == "" and task:
        department_id = None
    elif department_id is None and task:
        department_id = task.department_id

    if start_date < project.start_date or start_date > project.end_date:
        flash("Task start date must stay within the project timeline.", "danger")
        return None
    if due_date and (due_date < project.start_date or due_date > project.end_date):
        flash("Task due date must stay within the project timeline.", "danger")
        return None

    assigned_to = request.form.get("assigned_to", type=int)
    return {
        "title": title,
        "description": request.form.get("description", "").strip(),
        "status": status,
        "severity": severity,
        "start_date": start_date,
        "due_date": due_date,
        "project": project,
        "department_id": department_id,
        "assigned_to": assigned_to,
    }


def validate_subtask_payload(subtask: Subtask | None = None):
    title = request.form.get("title", "").strip()
    if not title:
        flash("Subtask title is required.", "danger")
        return None

    status = request.form.get("status", subtask.status if subtask else "ToDo")
    if status not in TASK_STATUSES:
        flash("Invalid subtask status selected.", "danger")
        return None

    task_id = request.form.get("task_id", type=int) or (subtask.task_id if subtask else None)
    parent_task = Task.query.get_or_404(task_id)
    due_date = parse_date(request.form.get("due_date"))
    if request.form.get("due_date") == "" and subtask:
        due_date = None
    elif due_date is None and subtask:
        due_date = subtask.due_date

    project = parent_task.project
    if due_date and (due_date < project.start_date or due_date > project.end_date):
        flash("Subtask due date must stay within the project timeline.", "danger")
        return None
    if due_date and due_date < parent_task.start_date:
        flash("Subtask due date cannot be before the parent task start date.", "danger")
        return None
    if due_date and parent_task.due_date and due_date > parent_task.due_date:
        flash("Subtask due date cannot be after the parent task due date.", "danger")
        return None

    return {
        "title": title,
        "status": status,
        "task": parent_task,
        "due_date": due_date,
    }


@admin_bp.route("/dashboard")
@login_required
@role_required("admin")
def dashboard():
    tasks = Task.query.order_by(Task.created_at.desc()).all()
    stats, status_segments, priority_bars = build_analytics(tasks)
    return render_template(
        "admin/dashboard.html",
        stats=stats,
        status_segments=status_segments,
        priority_bars=priority_bars,
        notifications=get_notifications(),
        active_page="dashboard",
    )


@admin_bp.route("/departments")
@login_required
@role_required("admin")
def departments():
    department_rows = []
    departments_list = Department.query.order_by(Department.name.asc()).all()
    for department in departments_list:
        department_rows.append(
            {
                "department": department,
                "project_count": len(department.projects),
                "task_count": sum(len(project.tasks) for project in department.projects),
            }
        )

    return render_template(
        "admin/departments.html",
        department_rows=department_rows,
        notifications=get_notifications(),
        active_page="departments",
    )


@admin_bp.route("/departments/create", methods=["POST"])
@login_required
@role_required("admin")
def create_department():
    name = request.form.get("name", "").strip()
    if not name:
        flash("Department name is required.", "danger")
        return redirect_target("admin.departments")

    exists = Department.query.filter(Department.name.ilike(name)).first()
    if exists:
        flash("Department already exists.", "warning")
        return redirect_target("admin.departments")

    db.session.add(Department(name=name))
    db.session.commit()
    flash("Department created successfully.", "success")
    return redirect_target("admin.departments")


@admin_bp.route("/departments/<int:department_id>/edit", methods=["POST"])
@login_required
@role_required("admin")
def edit_department(department_id: int):
    department = Department.query.get_or_404(department_id)
    name = request.form.get("name", "").strip()
    if not name:
        flash("Department name is required.", "danger")
        return redirect_target("admin.departments")

    exists = Department.query.filter(
        Department.id != department.id, Department.name.ilike(name)
    ).first()
    if exists:
        flash("Another department already uses that name.", "warning")
        return redirect_target("admin.departments")

    department.name = name
    db.session.commit()
    flash("Department updated successfully.", "success")
    return redirect_target("admin.departments")


@admin_bp.route("/departments/<int:department_id>/delete", methods=["POST"])
@login_required
@role_required("admin")
def delete_department(department_id: int):
    department = Department.query.get_or_404(department_id)
    Project.query.filter_by(department_id=department.id).update({"department_id": None})
    Task.query.filter_by(department_id=department.id).update({"department_id": None})
    db.session.delete(department)
    db.session.commit()
    flash("Department deleted successfully.", "info")
    return redirect_target("admin.departments")


@admin_bp.route("/projects")
@login_required
@role_required("admin")
def projects():
    projects_list = Project.query.order_by(Project.created_at.desc()).all()
    project_summaries = [build_project_summary(project) for project in projects_list]

    return render_template(
        "admin/projects.html",
        project_summaries=project_summaries,
        notifications=get_notifications(),
        active_page="projects",
    )


def _admin_export_context(filters):
    query = Task.query
    query = apply_task_export_filters(query, filters, Task)
    tasks = query.order_by(Task.due_date.is_(None), Task.due_date.asc(), Task.created_at.desc()).all()
    summary, project_rows = build_export_snapshot(tasks)

    return {
        "tasks": tasks,
        "summary": summary,
        "project_rows": project_rows,
        "projects": Project.query.order_by(Project.name.asc()).all(),
        "users": User.query.order_by(User.username.asc()).all(),
        "notifications": get_notifications(),
    }


@admin_bp.route("/export")
@login_required
@role_required("admin")
def export_page():
    filters = normalize_filters(request.args, include_assignee=True)
    try:
        date_from = parse_filter_date(filters["date_from"])
        date_to = parse_filter_date(filters["date_to"])
    except ValueError:
        flash("Please use valid export dates.", "danger")
        return redirect(url_for("admin.export_page"))

    if date_from and date_to and date_to < date_from:
        flash("Export end date cannot be before the start date.", "warning")
        return redirect(url_for("admin.export_page"))

    context = _admin_export_context(filters)
    user_lookup = {user.id: user.username for user in context["users"]}

    return render_template(
        "reports/export.html",
        scope="admin",
        filters=filters,
        filter_badges=build_filter_badges(
            filters,
            {project.id: project.name for project in context["projects"]},
            user_lookup,
        ),
        active_page="export",
        export_endpoint="admin.download_export_pdf",
        title_text="Export Reports",
        subtitle_text="Download a polished PDF report using project, status, member, severity, and due-date filters.",
        **context,
    )


@admin_bp.route("/export/download")
@login_required
@role_required("admin")
def download_export_pdf():
    filters = normalize_filters(request.args, include_assignee=True)
    try:
        date_from = parse_filter_date(filters["date_from"])
        date_to = parse_filter_date(filters["date_to"])
    except ValueError:
        flash("Please use valid export dates.", "danger")
        return redirect(url_for("admin.export_page", **request.args))

    if date_from and date_to and date_to < date_from:
        flash("Export end date cannot be before the start date.", "warning")
        return redirect(url_for("admin.export_page", **request.args))

    context = _admin_export_context(filters)
    projects = context["projects"]
    users = context["users"]
    try:
        pdf_buffer = render_task_export_pdf(
            report_title="Admin Project Export",
            report_subtitle="Workspace-wide project and task report",
            summary=context["summary"],
            filter_badges=build_filter_badges(
                filters,
                {project.id: project.name for project in projects},
                {user.id: user.username for user in users},
            ),
            project_rows=context["project_rows"],
            tasks=context["tasks"],
            generated_by=current_user.username,
        )
    except RuntimeError:
        flash("PDF export requires the reportlab package. Please install project requirements first.", "danger")
        return redirect(url_for("admin.export_page", **request.args.to_dict()))
    filename = f"admin-project-export-{datetime.now().strftime('%Y%m%d-%H%M%S')}.pdf"
    return send_file(pdf_buffer, as_attachment=True, download_name=filename, mimetype="application/pdf")


@admin_bp.route("/projects/create", methods=["POST"])
@login_required
@role_required("admin")
def create_project():
    name = request.form.get("name", "").strip()
    start_date = parse_date(request.form.get("start_date"))
    end_date = parse_date(request.form.get("end_date"))
    if not name:
        flash("Project name is required.", "danger")
        return redirect_target("admin.projects")
    if not validate_project_dates(start_date, end_date):
        return redirect_target("admin.projects")

    project = Project(
        name=name,
        description=request.form.get("description", "").strip(),
        start_date=start_date,
        end_date=end_date,
    )
    db.session.add(project)
    db.session.commit()
    flash("Project created successfully.", "success")
    return redirect_target("admin.projects")


@admin_bp.route("/projects/<int:project_id>")
@login_required
@role_required("admin")
def project_detail(project_id: int):
    project = Project.query.get_or_404(project_id)
    tasks = (
        Task.query.filter_by(project_id=project.id)
        .order_by(Task.due_date.is_(None), Task.due_date.asc(), Task.created_at.desc())
        .all()
    )
    task_summaries = [build_task_summary(task) for task in tasks]
    project_summary = build_project_summary(project)

    return render_template(
        "admin/project_detail.html",
        project=project,
        project_summary=project_summary,
        task_summaries=task_summaries,
        departments=Department.query.order_by(Department.name.asc()).all(),
        users=User.query.order_by(User.username.asc()).all(),
        task_statuses=TASK_STATUSES,
        task_severities=TASK_SEVERITIES,
        notifications=get_notifications(),
        active_page="projects",
    )


@admin_bp.route("/projects/<int:project_id>/edit", methods=["POST"])
@login_required
@role_required("admin")
def edit_project(project_id: int):
    project = Project.query.get_or_404(project_id)
    name = request.form.get("name", "").strip()
    start_date = parse_date(request.form.get("start_date")) or project.start_date
    end_date = parse_date(request.form.get("end_date")) or project.end_date

    if not name:
        flash("Project name is required.", "danger")
        return redirect_target("admin.projects")
    if not validate_project_dates(start_date, end_date):
        return redirect_target("admin.projects")

    project.name = name
    project.description = request.form.get("description", "").strip()
    project.start_date = start_date
    project.end_date = end_date
    db.session.commit()
    flash("Project updated successfully.", "success")
    return redirect_target("admin.project_detail", project_id=project.id)


@admin_bp.route("/projects/<int:project_id>/delete", methods=["POST"])
@login_required
@role_required("admin")
def delete_project(project_id: int):
    project = Project.query.get_or_404(project_id)
    db.session.delete(project)
    db.session.commit()
    flash("Project deleted successfully.", "info")
    return redirect_target("admin.projects")


@admin_bp.route("/tasks/create", methods=["POST"])
@login_required
@role_required("admin")
def create_task():
    payload = validate_task_payload()
    if payload is None:
        project_id = request.form.get("project_id", type=int)
        return redirect_target("admin.project_detail", project_id=project_id)

    task = Task(
        project_id=payload["project"].id,
        department_id=payload["department_id"],
        assigned_to=payload["assigned_to"],
        title=payload["title"],
        description=payload["description"],
        severity=payload["severity"],
        status=payload["status"],
        start_date=payload["start_date"],
        due_date=payload["due_date"],
    )
    db.session.add(task)
    db.session.commit()

    if task.assigned_to:
        NotificationService.notify_assignment(task, actor_username=current_user.username)
    flash("Task created successfully.", "success")
    return redirect_target("admin.project_detail", project_id=task.project_id)


@admin_bp.route("/tasks/<int:task_id>/edit", methods=["POST"])
@login_required
@role_required("admin")
def edit_task(task_id: int):
    task = Task.query.get_or_404(task_id)
    old_assignee = task.assigned_to
    payload = validate_task_payload(task)
    if payload is None:
        return redirect_target("admin.project_detail", project_id=task.project_id)
    if payload["status"] == "Completed" and any(
        subtask.status != "Completed" for subtask in task.subtasks
    ):
        flash("Complete all subtasks before marking the parent task as completed.", "warning")
        return redirect_target("admin.project_detail", project_id=task.project_id)

    task.project_id = payload["project"].id
    task.department_id = payload["department_id"]
    task.assigned_to = payload["assigned_to"]
    task.title = payload["title"]
    task.description = payload["description"]
    task.severity = payload["severity"]
    task.status = payload["status"]
    task.start_date = payload["start_date"]
    task.due_date = payload["due_date"]
    db.session.commit()

    if task.assigned_to and task.assigned_to != old_assignee:
        NotificationService.notify_assignment(task, actor_username=current_user.username)

    flash("Task updated successfully.", "success")
    return redirect_target("admin.project_detail", project_id=task.project_id)


@admin_bp.route("/tasks/<int:task_id>/delete", methods=["POST"])
@login_required
@role_required("admin")
def delete_task(task_id: int):
    task = Task.query.get_or_404(task_id)
    project_id = task.project_id
    db.session.delete(task)
    db.session.commit()
    flash("Task deleted successfully.", "info")
    return redirect_target("admin.project_detail", project_id=project_id)


@admin_bp.route("/subtasks/create", methods=["POST"])
@login_required
@role_required("admin")
def create_subtask():
    payload = validate_subtask_payload()
    if payload is None:
        project_id = request.form.get("project_id", type=int)
        return redirect_target("admin.project_detail", project_id=project_id)

    subtask = Subtask(
        task_id=payload["task"].id,
        title=payload["title"],
        status=payload["status"],
        due_date=payload["due_date"],
    )
    db.session.add(subtask)
    db.session.commit()
    flash("Subtask created successfully.", "success")
    return redirect_target("admin.project_detail", project_id=payload["task"].project_id)


@admin_bp.route("/subtasks/<int:subtask_id>/edit", methods=["POST"])
@login_required
@role_required("admin")
def edit_subtask(subtask_id: int):
    subtask = Subtask.query.get_or_404(subtask_id)
    payload = validate_subtask_payload(subtask)
    if payload is None:
        return redirect_target("admin.project_detail", project_id=subtask.task.project_id)

    subtask.task_id = payload["task"].id
    subtask.title = payload["title"]
    subtask.status = payload["status"]
    subtask.due_date = payload["due_date"]
    db.session.commit()
    flash("Subtask updated successfully.", "success")
    return redirect_target("admin.project_detail", project_id=subtask.task.project_id)


@admin_bp.route("/subtasks/<int:subtask_id>/delete", methods=["POST"])
@login_required
@role_required("admin")
def delete_subtask(subtask_id: int):
    subtask = Subtask.query.get_or_404(subtask_id)
    project_id = subtask.task.project_id
    db.session.delete(subtask)
    db.session.commit()
    flash("Subtask deleted successfully.", "info")
    return redirect_target("admin.project_detail", project_id=project_id)


@admin_bp.route("/members")
@login_required
@role_required("admin")
def members():
    users = User.query.order_by(User.created_at.desc()).all()
    member_rows = []
    for user in users:
        assigned_tasks = Task.query.filter_by(assigned_to=user.id).all()
        member_rows.append(
            {
                "user": user,
                "task_count": len(assigned_tasks),
                "completed_count": sum(task.status == "Completed" for task in assigned_tasks),
            }
        )

    return render_template(
        "admin/members.html",
        member_rows=member_rows,
        notifications=get_notifications(),
        active_page="members",
    )


@admin_bp.route("/members/<int:user_id>/edit", methods=["POST"])
@login_required
@role_required("admin")
def edit_member(user_id: int):
    user = User.query.get_or_404(user_id)
    username = request.form.get("username", "").strip()
    role = request.form.get("role", "").strip()
    password = request.form.get("password", "").strip()

    if not username:
        flash("Username is required.", "danger")
        return redirect_target("admin.members")
    if role not in {"admin", "user"}:
        flash("Invalid role selected.", "danger")
        return redirect_target("admin.members")

    exists = User.query.filter(User.id != user.id, User.username == username).first()
    if exists:
        flash("Another member already uses that username.", "warning")
        return redirect_target("admin.members")

    user.username = username
    user.role = role
    if password:
        if len(password) < 6:
            flash("Password must be at least 6 characters long.", "danger")
            return redirect_target("admin.members")
        user.set_password(password)

    db.session.commit()
    flash("Member updated successfully.", "success")
    return redirect_target("admin.members")


@admin_bp.route("/members/<int:user_id>/delete", methods=["POST"])
@login_required
@role_required("admin")
def delete_member(user_id: int):
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash("You cannot delete your own account while logged in.", "warning")
        return redirect_target("admin.members")
    if user.role == "admin" and User.query.filter_by(role="admin").count() == 1:
        flash("At least one admin account must remain.", "warning")
        return redirect_target("admin.members")

    db.session.delete(user)
    db.session.commit()
    flash("Member deleted successfully.", "info")
    return redirect_target("admin.members")
