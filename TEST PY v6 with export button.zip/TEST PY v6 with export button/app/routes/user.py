from datetime import date, datetime, timedelta

from flask import Blueprint, flash, redirect, render_template, request, send_file, url_for
from flask_login import current_user, login_required
from sqlalchemy import or_

from app.extensions import db
from app.models import Notification, Project, Subtask, Task, TaskComment, User
from app.reporting import (
    apply_task_export_filters,
    build_export_snapshot,
    build_filter_badges,
    normalize_filters,
    parse_filter_date,
    render_task_export_pdf,
)
from app.utils import NotificationService, TASK_SEVERITIES, TASK_STATUSES, role_required

user_bp = Blueprint("user", __name__, url_prefix="/user")


def build_user_analytics(tasks):
    today = date.today()
    tomorrow = today + timedelta(days=1)
    assigned_projects = {task.project_id for task in tasks}

    stats = {
        "total_projects": len(assigned_projects),
        "total_tasks": len(tasks),
        "completed_tasks": sum(task.status == "Completed" for task in tasks),
        "pending_tasks": sum(task.status != "Completed" for task in tasks),
        "overdue_tasks": sum(
            task.status != "Completed" and task.due_date is not None and task.due_date < today
            for task in tasks
        ),
        "no_deadline_tasks": sum(task.due_date is None for task in tasks),
        "due_tomorrow_tasks": sum(
            task.status != "Completed" and task.due_date == tomorrow for task in tasks
        ),
    }

    status_counts = {status: 0 for status in TASK_STATUSES}
    priority_counts = {severity: 0 for severity in TASK_SEVERITIES}
    for task in tasks:
        status_counts[task.status] = status_counts.get(task.status, 0) + 1
        priority_counts[task.severity] = priority_counts.get(task.severity, 0) + 1

    total_status = sum(status_counts.values()) or 1
    offset = 0
    status_colors = {
        "ToDo": "#94a3b8",
        "In Progress": "#3b82f6",
        "Review": "#facc15",
        "Completed": "#22c55e",
    }
    status_segments = []
    for label, value in status_counts.items():
        percentage = round((value / total_status) * 100, 2)
        status_segments.append(
            {
                "label": label,
                "value": value,
                "percentage": percentage,
                "start": round(offset, 2),
                "end": round(offset + percentage, 2),
                "color": status_colors[label],
            }
        )
        offset += percentage

    max_priority = max(priority_counts.values(), default=0) or 1
    priority_colors = {
        "Low": "#d6d3d1",
        "Medium": "#f59e0b",
        "High": "#ef4444",
        "Critical": "#991b1b",
    }
    priority_bars = [
        {
            "label": label,
            "value": value,
            "height_pct": round((value / max_priority) * 100, 2),
            "color": priority_colors[label],
        }
        for label, value in priority_counts.items()
    ]

    return stats, status_segments, priority_bars


def redirect_user_back():
    target = request.referrer
    if target:
        return redirect(target)
    return redirect(url_for("user.dashboard"))


@user_bp.route("/dashboard")
@login_required
@role_required("user", "admin")
def dashboard():
    NotificationService.sync_deadline_notifications_for_user(current_user.id)

    page = request.args.get("page", 1, type=int)
    search = request.args.get("search", "", type=str).strip()
    status = request.args.get("status", "", type=str).strip()

    query = Task.query.filter(Task.assigned_to == current_user.id)
    if search:
        query = query.join(Project).filter(
            or_(
                Task.title.ilike(f"%{search}%"),
                Task.description.ilike(f"%{search}%"),
                Project.name.ilike(f"%{search}%"),
            )
        )
    if status:
        query = query.filter(Task.status == status)

    pagination = query.order_by(Task.due_date.is_(None), Task.due_date.asc()).paginate(
        page=page,
        per_page=8,
        error_out=False,
    )

    all_tasks = (
        Task.query.filter(Task.assigned_to == current_user.id)
        .order_by(Task.due_date.is_(None), Task.due_date.asc())
        .all()
    )
    stats, status_segments, priority_bars = build_user_analytics(all_tasks)

    latest_notifications = (
        Notification.query.filter_by(user_id=current_user.id, is_read=False)
        .order_by(Notification.created_at.desc())
        .limit(8)
        .all()
    )

    return render_template(
        "user/dashboard.html",
        stats=stats,
        status_segments=status_segments,
        priority_bars=priority_bars,
        notifications=latest_notifications,
        filters={"search": search, "status": status},
        task_statuses=TASK_STATUSES,
        active_page="dashboard",
    )


@user_bp.route("/projects")
@login_required
@role_required("user", "admin")
def projects():
    NotificationService.sync_deadline_notifications_for_user(current_user.id)

    all_tasks = (
        Task.query.filter(Task.assigned_to == current_user.id)
        .order_by(Task.due_date.is_(None), Task.due_date.asc())
        .all()
    )
    assigned_projects = (
        Project.query.join(Task)
        .filter(Task.assigned_to == current_user.id)
        .distinct()
        .order_by(Project.created_at.desc())
        .all()
    )
    project_summaries = []
    for project in assigned_projects:
        assigned_project_tasks = [task for task in all_tasks if task.project_id == project.id]
        total_tasks = len(assigned_project_tasks)
        completed_tasks = sum(task.status == "Completed" for task in assigned_project_tasks)
        total_subtasks = sum(len(task.subtasks) for task in assigned_project_tasks)
        completed_subtasks = sum(
            sum(subtask.status == "Completed" for subtask in task.subtasks)
            for task in assigned_project_tasks
        )
        completion_pct = int(round((completed_tasks / total_tasks) * 100)) if total_tasks else 0
        project_summaries.append(
            {
                "project": project,
                "total_tasks": total_tasks,
                "completed_tasks": completed_tasks,
                "total_subtasks": total_subtasks,
                "completed_subtasks": completed_subtasks,
                "completion_pct": completion_pct,
            }
        )

    latest_notifications = (
        Notification.query.filter_by(user_id=current_user.id, is_read=False)
        .order_by(Notification.created_at.desc())
        .limit(8)
        .all()
    )

    return render_template(
        "user/projects.html",
        project_summaries=project_summaries,
        notifications=latest_notifications,
        active_page="projects",
    )


def _user_export_context(filters):
    query = Task.query.filter(Task.assigned_to == current_user.id)
    query = apply_task_export_filters(query, filters, Task)
    tasks = query.order_by(Task.due_date.is_(None), Task.due_date.asc(), Task.created_at.desc()).all()
    summary, project_rows = build_export_snapshot(tasks)

    projects = (
        Project.query.join(Task)
        .filter(Task.assigned_to == current_user.id)
        .distinct()
        .order_by(Project.name.asc())
        .all()
    )
    notifications = (
        Notification.query.filter_by(user_id=current_user.id, is_read=False)
        .order_by(Notification.created_at.desc())
        .limit(8)
        .all()
    )
    return {
        "tasks": tasks,
        "summary": summary,
        "project_rows": project_rows,
        "projects": projects,
        "notifications": notifications,
    }


@user_bp.route("/export")
@login_required
@role_required("user", "admin")
def export_page():
    NotificationService.sync_deadline_notifications_for_user(current_user.id)

    filters = normalize_filters(request.args)
    try:
        date_from = parse_filter_date(filters["date_from"])
        date_to = parse_filter_date(filters["date_to"])
    except ValueError:
        flash("Please use valid export dates.", "danger")
        return redirect(url_for("user.export_page"))

    if date_from and date_to and date_to < date_from:
        flash("Export end date cannot be before the start date.", "warning")
        return redirect(url_for("user.export_page"))

    context = _user_export_context(filters)
    return render_template(
        "reports/export.html",
        scope="user",
        filters=filters,
        filter_badges=build_filter_badges(
            filters,
            {project.id: project.name for project in context["projects"]},
        ),
        active_page="export",
        export_endpoint="user.download_export_pdf",
        title_text="Export My Reports",
        subtitle_text="Filter your assigned work and download a colorful PDF report for sharing or updates.",
        **context,
    )


@user_bp.route("/export/download")
@login_required
@role_required("user", "admin")
def download_export_pdf():
    NotificationService.sync_deadline_notifications_for_user(current_user.id)

    filters = normalize_filters(request.args)
    try:
        date_from = parse_filter_date(filters["date_from"])
        date_to = parse_filter_date(filters["date_to"])
    except ValueError:
        flash("Please use valid export dates.", "danger")
        return redirect(url_for("user.export_page", **request.args))

    if date_from and date_to and date_to < date_from:
        flash("Export end date cannot be before the start date.", "warning")
        return redirect(url_for("user.export_page", **request.args))

    context = _user_export_context(filters)
    try:
        pdf_buffer = render_task_export_pdf(
            report_title="My Work Export",
            report_subtitle="Assigned project and task report",
            summary=context["summary"],
            filter_badges=build_filter_badges(
                filters,
                {project.id: project.name for project in context["projects"]},
            ),
            project_rows=context["project_rows"],
            tasks=context["tasks"],
            generated_by=current_user.username,
        )
    except RuntimeError:
        flash("PDF export requires the reportlab package. Please install project requirements first.", "danger")
        return redirect(url_for("user.export_page", **request.args.to_dict()))
    filename = f"user-project-export-{datetime.now().strftime('%Y%m%d-%H%M%S')}.pdf"
    return send_file(pdf_buffer, as_attachment=True, download_name=filename, mimetype="application/pdf")


@user_bp.route("/projects/<int:project_id>")
@login_required
@role_required("user", "admin")
def project_detail(project_id: int):
    NotificationService.sync_deadline_notifications_for_user(current_user.id)

    project = (
        Project.query.join(Task)
        .filter(Project.id == project_id, Task.assigned_to == current_user.id)
        .distinct()
        .first_or_404()
    )

    page = request.args.get("page", 1, type=int)
    search = request.args.get("search", "", type=str).strip()
    status = request.args.get("status", "", type=str).strip()
    severity = request.args.get("severity", "", type=str).strip()

    query = Task.query.filter(
        Task.assigned_to == current_user.id,
        Task.project_id == project.id,
    )
    if search:
        query = query.filter(
            or_(
                Task.title.ilike(f"%{search}%"),
                Task.description.ilike(f"%{search}%"),
            )
        )
    if status:
        query = query.filter(Task.status == status)
    if severity:
        query = query.filter(Task.severity == severity)

    pagination = query.order_by(Task.due_date.is_(None), Task.due_date.asc()).paginate(
        page=page,
        per_page=8,
        error_out=False,
    )

    project_tasks = (
        Task.query.filter(
            Task.assigned_to == current_user.id,
            Task.project_id == project.id,
        )
        .order_by(Task.due_date.is_(None), Task.due_date.asc())
        .all()
    )
    total_tasks = len(project_tasks)
    completed_tasks = sum(task.status == "Completed" for task in project_tasks)
    total_subtasks = sum(len(task.subtasks) for task in project_tasks)
    completed_subtasks = sum(
        sum(subtask.status == "Completed" for subtask in task.subtasks)
        for task in project_tasks
    )
    completion_pct = int(round((completed_tasks / total_tasks) * 100)) if total_tasks else 0

    latest_notifications = (
        Notification.query.filter_by(user_id=current_user.id, is_read=False)
        .order_by(Notification.created_at.desc())
        .limit(8)
        .all()
    )

    return render_template(
        "user/project_detail.html",
        project=project,
        task_pagination=pagination,
        project_summary={
            "total_tasks": total_tasks,
            "completed_tasks": completed_tasks,
            "total_subtasks": total_subtasks,
            "completed_subtasks": completed_subtasks,
            "completion_pct": completion_pct,
        },
        notifications=latest_notifications,
        filters={"search": search, "status": status, "severity": severity},
        task_statuses=TASK_STATUSES,
        task_severities=TASK_SEVERITIES,
        active_page="projects",
    )


@user_bp.route("/tasks/<int:task_id>/status", methods=["POST"])
@login_required
@role_required("user", "admin")
def update_task_status(task_id: int):
    task = Task.query.get_or_404(task_id)
    if task.assigned_to != current_user.id:
        flash("You are not authorized to update this task.", "danger")
        return redirect_user_back()

    new_status = request.form.get("status", "").strip()
    status_order = {"ToDo": 0, "In Progress": 1, "Review": 2, "Completed": 3}
    if new_status not in status_order:
        flash("Invalid task status provided.", "danger")
        return redirect_user_back()

    if status_order[new_status] < status_order.get(task.status, 0):
        flash("Task status cannot move backwards.", "warning")
        return redirect_user_back()
    if new_status == "Completed" and any(
        subtask.status != "Completed" for subtask in task.subtasks
    ):
        flash("Complete all subtasks before marking the parent task as completed.", "warning")
        return redirect_user_back()

    task.status = new_status
    db.session.commit()
    flash("Task status updated.", "success")
    return redirect_user_back()


@user_bp.route("/tasks/<int:task_id>/comment", methods=["POST"])
@login_required
@role_required("user", "admin")
def add_task_comment(task_id: int):
    task = Task.query.get_or_404(task_id)
    if task.assigned_to != current_user.id:
        flash("You can only comment on your assigned tasks.", "danger")
        return redirect_user_back()

    body = request.form.get("body", "").strip()
    if not body:
        flash("Comment cannot be empty.", "danger")
        return redirect_user_back()

    comment = TaskComment(task_id=task.id, user_id=current_user.id, body=body)
    db.session.add(comment)
    db.session.commit()

    snippet = (body[:70] + "...") if len(body) > 70 else body
    message = f"Remark from {current_user.username} on task '{task.title}': {snippet}"[:255]
    admin_users = User.query.filter(User.role == "admin", User.id != current_user.id).all()
    for admin in admin_users:
        NotificationService.create_notification(admin.id, message, "remark")

    flash("Comment added.", "success")
    return redirect_user_back()


@user_bp.route("/subtasks/<int:subtask_id>/status", methods=["POST"])
@login_required
@role_required("user", "admin")
def update_subtask_status(subtask_id: int):
    subtask = Subtask.query.get_or_404(subtask_id)
    if subtask.task.assigned_to != current_user.id:
        flash("You are not authorized to update this subtask.", "danger")
        return redirect_user_back()

    new_status = request.form.get("status", "").strip()
    status_order = {"ToDo": 0, "In Progress": 1, "Review": 2, "Completed": 3}
    if new_status not in status_order:
        flash("Invalid subtask status provided.", "danger")
        return redirect_user_back()

    if status_order[new_status] < status_order.get(subtask.status, 0):
        flash("Subtask status cannot move backwards.", "warning")
        return redirect_user_back()

    subtask.status = new_status
    db.session.commit()
    flash("Subtask status updated.", "success")
    return redirect_user_back()
