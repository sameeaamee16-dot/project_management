function openModal(selector) {
  closeAllModals();
  const modal = document.querySelector(selector);
  if (!modal) return;
  modal.classList.remove("hidden");
  document.body.classList.add("modal-open");
}

function closeModal(modal) {
  modal.classList.add("hidden");
  if (!document.querySelector(".modal:not(.hidden)")) {
    document.body.classList.remove("modal-open");
  }
}

function closeAllModals() {
  document.querySelectorAll(".modal").forEach((modal) => modal.classList.add("hidden"));
  document.body.classList.remove("modal-open");
}

function setFieldValue(id, value) {
  const field = document.getElementById(id);
  if (field) {
    field.value = value || "";
  }
}

function initializeModals() {
  document.querySelectorAll("[data-modal-target]").forEach((button) => {
    button.addEventListener("click", () => {
      const target = button.getAttribute("data-modal-target");
      openModal(target);

      if (target === "#editDepartmentModal") {
        const form = document.getElementById("editDepartmentForm");
        if (form) {
          form.action = `/admin/departments/${button.dataset.departmentId}/edit`;
        }
        setFieldValue("editDepartmentName", button.dataset.departmentName);
      }

      if (target === "#editProjectModal") {
        const form = document.getElementById("editProjectForm");
        if (form) {
          form.action = `/admin/projects/${button.dataset.projectId}/edit`;
        }
        setFieldValue("editProjectName", button.dataset.projectName);
        setFieldValue("editProjectDescription", button.dataset.projectDescription);
        setFieldValue("editProjectStart", button.dataset.projectStart);
        setFieldValue("editProjectEnd", button.dataset.projectEnd);
        setFieldValue("editProjectNextUrl", button.dataset.nextUrl);
      }

      if (target === "#editTaskModal") {
        const form = document.getElementById("editTaskForm");
        if (form) {
          form.action = `/admin/tasks/${button.dataset.taskId}/edit`;
        }
        setFieldValue("editTaskTitle", button.dataset.taskTitle);
        setFieldValue("editTaskDescription", button.dataset.taskDescription);
        setFieldValue("editTaskProject", button.dataset.taskProject);
        setFieldValue("editTaskDepartment", button.dataset.taskDepartment);
        setFieldValue("editTaskUser", button.dataset.taskUser);
        setFieldValue("editTaskSeverity", button.dataset.taskSeverity);
        setFieldValue("editTaskStatus", button.dataset.taskStatus);
        setFieldValue("editTaskStart", button.dataset.taskStart);
        setFieldValue("editTaskDue", button.dataset.taskDue);
        setFieldValue("editTaskNextUrl", button.dataset.nextUrl);
      }

      if (target === "#editSubtaskModal") {
        const form = document.getElementById("editSubtaskForm");
        if (form) {
          form.action = `/admin/subtasks/${button.dataset.subtaskId}/edit`;
        }
        setFieldValue("editSubtaskTaskId", button.dataset.subtaskTask);
        setFieldValue("editSubtaskTitle", button.dataset.subtaskTitle);
        setFieldValue("editSubtaskStatus", button.dataset.subtaskStatus);
        setFieldValue("editSubtaskDue", button.dataset.subtaskDue);
        setFieldValue("editSubtaskNextUrl", button.dataset.nextUrl);
      }

      if (target === "#editMemberModal") {
        const form = document.getElementById("editMemberForm");
        if (form) {
          form.action = `/admin/members/${button.dataset.memberId}/edit`;
        }
        setFieldValue("editMemberUsername", button.dataset.memberUsername);
        setFieldValue("editMemberRole", button.dataset.memberRole);
      }
    });
  });

  document.querySelectorAll(".close-modal").forEach((button) => {
    button.addEventListener("click", () => {
      const modal = button.closest(".modal");
      if (modal) closeModal(modal);
    });
  });

  document.querySelectorAll(".modal").forEach((modal) => {
    modal.addEventListener("click", (event) => {
      if (event.target === modal) {
        closeModal(modal);
      }
    });
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      closeAllModals();
    }
  });
}

function initializeConfirmations() {
  document.querySelectorAll("[data-confirm]").forEach((button) => {
    button.addEventListener("click", (event) => {
      const message = button.getAttribute("data-confirm");
      if (message && !window.confirm(message)) {
        event.preventDefault();
      }
    });
  });
}

async function markNotificationAsRead(id) {
  await fetch(`/api/notifications/${id}/read`, { method: "POST" });
}

function renderNotifications(items) {
  const list = document.getElementById("notifList");
  const countNode = document.getElementById("notifCount");
  if (!list || !countNode) return;

  countNode.textContent = String(items.length);
  if (!items.length) {
    list.innerHTML = '<li class="muted">No new notifications.</li>';
    return;
  }

  list.innerHTML = items
    .map(
      (item) => `
      <li data-id="${item.id}">
        <span class="notif-type ${item.type}">${item.type.toUpperCase()}</span>
        <p>${item.message}</p>
        <small>${item.created_at}</small>
      </li>`
    )
    .join("");

  list.querySelectorAll("li[data-id]").forEach((li) => {
    li.addEventListener("click", async () => {
      await markNotificationAsRead(li.dataset.id);
      li.remove();
      const newCount = list.querySelectorAll("li[data-id]").length;
      countNode.textContent = String(newCount);
      if (!newCount) {
        list.innerHTML = '<li class="muted">No new notifications.</li>';
      }
    });
  });
}

async function pollNotifications() {
  try {
    const response = await fetch("/api/notifications/poll");
    if (!response.ok) return;
    const payload = await response.json();
    renderNotifications(payload.notifications || []);
  } catch (error) {
    console.error("Notification polling failed", error);
  }
}

function initializeNotifications() {
  const toggle = document.getElementById("notifToggle");
  const dropdown = document.getElementById("notifDropdown");
  const markAll = document.getElementById("markAllReadBtn");

  if (!toggle || !dropdown) return;

  toggle.addEventListener("click", () => {
    dropdown.classList.toggle("hidden");
  });

  document.addEventListener("click", (event) => {
    if (!dropdown.contains(event.target) && !toggle.contains(event.target)) {
      dropdown.classList.add("hidden");
    }
  });

  if (markAll) {
    markAll.addEventListener("click", async () => {
      await fetch("/api/notifications/read-all", { method: "POST" });
      renderNotifications([]);
    });
  }

  pollNotifications();
  setInterval(pollNotifications, 20000);
}

document.addEventListener("DOMContentLoaded", () => {
  initializeModals();
  initializeConfirmations();
  initializeNotifications();
});
